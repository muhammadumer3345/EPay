import { Component, OnInit } from '@angular/core';

import { Input } from '@angular/core';
import { DesignationService } from './designation.service';
import { Observable } from 'rxjs';

import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { throwError as observableThrowError } from 'rxjs';
import { IPayDesignation } from 'app/shared/models/IPayDesignation';

@Component({
  selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css'],
  providers: [DesignationService], 
})
export class DesignationComponent implements OnInit {



  dataSource: IPayDesignation[]= [];


  ngOnInit(): void {
    debugger;
    this.classService.getDesignations()
        .subscribe(data => {
          debugger;
          console.log(data);
          this.dataSource = data;
         
        },
          err => {
            console.log(err);
          }
        );
  }
  constructor(private classService: DesignationService,
    private _httpClient: HttpClient, 
  ) { }


}
